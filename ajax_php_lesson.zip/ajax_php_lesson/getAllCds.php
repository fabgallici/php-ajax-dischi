<?php
header('Content-Type: application/json');
include 'cds.php';
echo json_encode($cds);
?>